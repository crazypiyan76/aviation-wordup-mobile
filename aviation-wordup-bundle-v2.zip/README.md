# Aviation WordUp

978 個航空維修英文單字的行動版字卡，包含來源例句、中文翻譯、朗讀、熟悉度、星號與「再看一遍」。

- iPad / iPhone: GitHub Pages 網頁 App，可加入主畫面。
- Android: GitHub Actions 自動產生可安裝 APK。
